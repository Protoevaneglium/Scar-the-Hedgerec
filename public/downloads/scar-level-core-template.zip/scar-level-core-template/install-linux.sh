#!/usr/bin/env sh
# Scar the Hedgerec - Linux & macOS First-Time Auto-Installer & "scar" Launcher Generator
# One-line First-Time Install:
#   curl -fsSL https://raw.githubusercontent.com/Protoevaneglium/Scar-the-Hedgerec/master/install-linux.sh | sh
# Or with wget:
#   wget -qO- https://raw.githubusercontent.com/Protoevaneglium/Scar-the-Hedgerec/master/install-linux.sh | sh

set -e

REPO_URL="https://github.com/Protoevaneglium/Scar-the-Hedgerec.git"
TAR_URL_MAIN="https://github.com/Protoevaneglium/Scar-the-Hedgerec/archive/refs/heads/main.tar.gz"
TAR_URL_MASTER="https://github.com/Protoevaneglium/Scar-the-Hedgerec/archive/refs/heads/master.tar.gz"

QUIET=0
if [ "${1:-}" = "--quiet" ]; then
    QUIET=1
fi

log() {
    if [ "$QUIET" -eq 0 ]; then
        echo "$@"
    fi
}

# 1. Detect Node.js (`node` or `nodejs`) and auto-install if possible
NODE_BIN=""
if command -v node >/dev/null 2>&1; then
    NODE_BIN="node"
elif command -v nodejs >/dev/null 2>&1; then
    NODE_BIN="nodejs"
fi

if [ -z "$NODE_BIN" ]; then
    SUDO=""
    if [ "$(id -u 2>/dev/null || echo 1)" -eq 0 ]; then
        SUDO=""
    elif command -v sudo >/dev/null 2>&1 && sudo -n true >/dev/null 2>&1; then
        SUDO="sudo"
    fi

    if command -v pkg >/dev/null 2>&1; then
        log "Installing Node.js via pkg..."
        pkg update -y && pkg install -y nodejs || true
    elif [ "$(id -u 2>/dev/null || echo 1)" -eq 0 ] || [ -n "$SUDO" ]; then
        if command -v apt-get >/dev/null 2>&1; then
            log "Installing Node.js via apt-get..."
            $SUDO apt-get update -y && $SUDO apt-get install -y nodejs || true
        elif command -v dnf >/dev/null 2>&1; then
            log "Installing Node.js via dnf..."
            $SUDO dnf install -y nodejs || true
        elif command -v pacman >/dev/null 2>&1; then
            log "Installing Node.js via pacman..."
            $SUDO pacman -Sy --noconfirm nodejs || true
        elif command -v apk >/dev/null 2>&1; then
            log "Installing Node.js via apk..."
            $SUDO apk add --no-cache nodejs || true
        elif command -v zypper >/dev/null 2>&1; then
            log "Installing Node.js via zypper..."
            $SUDO zypper --non-interactive install nodejs || true
        fi
    elif command -v brew >/dev/null 2>&1; then
        log "Installing Node.js via Homebrew..."
        brew install node || true
    fi

    if command -v node >/dev/null 2>&1; then
        NODE_BIN="node"
    elif command -v nodejs >/dev/null 2>&1; then
        NODE_BIN="nodejs"
    else
        log "Note: Node.js was not detected. Install nodejs with your package manager (e.g. 'sudo apt install -y nodejs' or 'brew install node') for full server & audio support."
    fi
fi

# 2. Locate existing repo checkout or install/update ~/Scar-the-Hedgerec
SCRIPT_DIR=""
if [ -n "$0" ] && [ "$0" != "sh" ] && [ "$0" != "-sh" ] && [ "$0" != "bash" ] && [ "$0" != "-bash" ]; then
    SCRIPT_DIR="$(cd "$(dirname "$0")" 2>/dev/null && pwd || true)"
fi

if [ -n "$SCRIPT_DIR" ] && [ -f "$SCRIPT_DIR/server.js" ]; then
    GAME_DIR="$SCRIPT_DIR"
elif [ -f "./server.js" ]; then
    GAME_DIR="$(pwd)"
else
    GAME_DIR="${HOME}/Scar-the-Hedgerec"
    if [ -e "$GAME_DIR/.git" ]; then
        log "Updating existing Scar the Hedgerec in $GAME_DIR ..."
        # BEGIN SAFE EXISTING UPDATE
        if ! command -v git >/dev/null 2>&1; then
            log "Skipping update: Git is unavailable. Local work preserved."
        elif ! DIRTY="$(git -C "$GAME_DIR" status --porcelain 2>/dev/null)"; then
            log "Skipping update: cannot inspect this checkout. Local work preserved."
        elif [ -n "$DIRTY" ]; then
            log "Skipping update: this checkout has local changes. Local work preserved."
        else
            BRANCH="$(git -C "$GAME_DIR" symbolic-ref --quiet --short HEAD 2>/dev/null || true)"
            if [ -z "$BRANCH" ]; then
                log "Skipping update: this checkout is detached. Local work preserved."
            elif ! git -C "$GAME_DIR" pull --ff-only origin "$BRANCH"; then
                log "Could not fast-forward this checkout. Local commits and files preserved."
            fi
        fi
        # END SAFE EXISTING UPDATE
    elif [ ! -d "$GAME_DIR" ] && command -v git >/dev/null 2>&1; then
        log "Cloning Scar the Hedgerec into $GAME_DIR ..."
        git clone "$REPO_URL" "$GAME_DIR"
    else
        log "Downloading latest Scar the Hedgerec archive into $GAME_DIR ..."
        TMP_DIR="$(mktemp -d 2>/dev/null || echo "/tmp/scar-install-$$")"
        mkdir -p "$TMP_DIR" "$GAME_DIR"
        TAR_FILE="$TMP_DIR/scar.tar.gz"
        DOWNLOAD_OK=0

        for URL in "$TAR_URL_MASTER" "$TAR_URL_MAIN"; do
            if command -v curl >/dev/null 2>&1; then
                if curl -fsSL "$URL" -o "$TAR_FILE" 2>/dev/null; then
                    DOWNLOAD_OK=1
                    break
                fi
            elif command -v wget >/dev/null 2>&1; then
                if wget -qO "$TAR_FILE" "$URL" 2>/dev/null; then
                    DOWNLOAD_OK=1
                    break
                fi
            fi
        done

        if [ "$DOWNLOAD_OK" -eq 1 ] && [ -f "$TAR_FILE" ]; then
            tar -xzf "$TAR_FILE" -C "$TMP_DIR"
            SRC_EXTRACT="$(find "$TMP_DIR" -mindepth 1 -maxdepth 1 -type d | head -n 1)"
            if [ -n "$SRC_EXTRACT" ] && [ -d "$SRC_EXTRACT" ]; then
                cp -R "$SRC_EXTRACT"/. "$GAME_DIR"/
            fi
            rm -rf "$TMP_DIR"
        else
            echo "Error: Could not download Scar the Hedgerec. Git or curl/wget is required."
            exit 1
        fi
    fi
fi

# 3. Auto-generate the global executable `scar` command & `~/scar.sh`
if [ -n "${PREFIX:-}" ] && [ -d "${PREFIX}/bin" ] && [ -w "${PREFIX}/bin" ]; then
    BIN_DIR="${PREFIX}/bin"
else
    BIN_DIR="${HOME}/.local/bin"
    mkdir -p "$BIN_DIR"
fi

SCAR_CMD="${BIN_DIR}/scar"
SCAR_SH="${HOME}/scar.sh"

cat > "$SCAR_CMD" <<EOF
#!/usr/bin/env sh
# Auto-generated launcher for Scar the Hedgerec
cd "${GAME_DIR}" || exit 1
if command -v node >/dev/null 2>&1; then
    exec node server.js --open "\$@"
elif command -v nodejs >/dev/null 2>&1; then
    exec nodejs server.js --open "\$@"
elif command -v open >/dev/null 2>&1; then
    exec open "${GAME_DIR}/public/index.html"
elif command -v xdg-open >/dev/null 2>&1; then
    exec xdg-open "${GAME_DIR}/public/index.html"
else
    echo "Please install Node.js (e.g. sudo apt install -y nodejs or brew install node) or open ${GAME_DIR}/public/index.html"
    exit 1
fi
EOF
chmod +x "$SCAR_CMD"

cp "$SCAR_CMD" "$SCAR_SH"
chmod +x "$SCAR_SH"

# Also copy to /usr/local/bin/scar if writable without sudo (instant PATH on many Linux/macOS setups)
if [ -d "/usr/local/bin" ] && [ -w "/usr/local/bin" ]; then
    cp "$SCAR_CMD" "/usr/local/bin/scar" 2>/dev/null || true
    chmod +x "/usr/local/bin/scar" 2>/dev/null || true
fi

# 4. Ensure ~/.local/bin is in PATH and `scar` alias exists across bash, zsh & login shells
PATH_LINE='export PATH="$HOME/.local/bin:$PATH"'
ALIAS_LINE="alias scar='sh \"${SCAR_SH}\"'"

update_rc() {
    RC_FILE="$1"
    if [ -f "$RC_FILE" ]; then
        grep -Fq ".local/bin" "$RC_FILE" 2>/dev/null || printf "\n# Scar the Hedgerec PATH\n%s\n" "$PATH_LINE" >> "$RC_FILE"
        grep -Fq "scar.sh" "$RC_FILE" 2>/dev/null || printf "%s\n" "$ALIAS_LINE" >> "$RC_FILE"
    fi
}

update_rc "${HOME}/.bashrc"
update_rc "${HOME}/.zshrc"
update_rc "${HOME}/.profile"
update_rc "${HOME}/.zprofile"
if [ ! -f "${HOME}/.bashrc" ] && [ ! -f "${HOME}/.zshrc" ]; then
    printf "# Scar the Hedgerec quick launcher\n%s\n%s\n" "$PATH_LINE" "$ALIAS_LINE" > "${HOME}/.bashrc"
fi

# 5. Optional Linux Desktop shortcut entry (~/.local/share/applications)
if [ -d "${HOME}/.local/share/applications" ]; then
    DESKTOP_FILE="${HOME}/.local/share/applications/scar-the-hedgerec.desktop"
    cat > "$DESKTOP_FILE" <<EOF
[Desktop Entry]
Type=Application
Name=Scar the Hedgerec
Comment=Launch Scar the Hedgerec 16-bit Platformer
Exec=${SCAR_CMD}
Path=${GAME_DIR}
Terminal=true
Categories=Game;ArcadeGame;
EOF
    chmod +x "$DESKTOP_FILE" 2>/dev/null || true
fi

if [ "$QUIET" -eq 0 ]; then
    echo ""
    echo "=========================================================="
    echo " Scar the Hedgerec is installed on Linux / macOS!"
    echo " Game directory : ${GAME_DIR}"
    echo " Generated cmd  : ${SCAR_CMD} (and ${SCAR_SH})"
    echo ""
    echo " HOW TO START EVERY TIME:"
    echo " Open any terminal window and type:"
    echo ""
    echo "     scar"
    echo ""
    echo " and press Enter to launch the server and browser!"
    echo " (To run immediately in this current terminal, type: sh ~/scar.sh)"
    echo "=========================================================="
fi
